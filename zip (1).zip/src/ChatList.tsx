import React, { useEffect, useState } from 'react';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';
import { Chat } from './types';
import { useAuth } from './AuthContext';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MessageSquare, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const ChatList: React.FC = () => {
  const { user, setShowLoginModal } = useAuth();
  const [chats, setChats] = useState<Chat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'chats'),
      where('participantIds', 'array-contains', user.uid),
      orderBy('updatedAt', 'desc') // We'll use updatedAt or createdAt
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedChats = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Chat[];
      
      // Sort by lastMessageAt locally if needed, since Firestore might complain about multiple inequalities
      fetchedChats.sort((a, b) => {
        const timeA = a.lastMessageAt?.toMillis() || a.createdAt?.toMillis() || 0;
        const timeB = b.lastMessageAt?.toMillis() || b.createdAt?.toMillis() || 0;
        return timeB - timeA;
      });

      setChats(fetchedChats);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching chats:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  return (
    <div className="pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto min-h-screen">
      <div className="mb-10">
        <h1 className="text-4xl font-bold tracking-tight text-gray-900 mb-2 flex items-center gap-3">
          <MessageSquare className="w-10 h-10 text-blue-600" />
          訊息
        </h1>
        <p className="text-lg text-gray-500 font-medium">
          繼續您與買家或賣家的對話。
        </p>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
        </div>
      ) : chats.length === 0 ? (
        <div className="text-center py-24 bg-gray-50 rounded-3xl border border-gray-100">
          <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">沒有進行中的對話</h3>
          <p className="text-gray-500">當您聯絡賣家時，您的訊息會顯示在這裡。</p>
        </div>
      ) : (
        <div className="space-y-4">
          {chats.map((chat, index) => (
            <motion.div
              key={chat.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Link to={`/chat/${chat.id}`} className="block">
                <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-sm border border-gray-100 hover:shadow-md hover:border-gray-200 transition-all flex items-center gap-4 sm:gap-6">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0 border border-gray-200">
                    <img 
                      src={chat.listingImageUrl} 
                      alt={chat.listingTitle} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-grow min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <h3 className="text-lg font-bold text-gray-900 truncate pr-4">
                        {chat.listingTitle}
                      </h3>
                      {(chat.lastMessageAt || chat.createdAt) && (
                        <span className="text-xs text-gray-500 flex-shrink-0 flex items-center gap-1 mt-1">
                          <Clock className="w-3 h-3" />
                          {formatDistanceToNow((chat.lastMessageAt || chat.createdAt).toDate(), { addSuffix: true })}
                        </span>
                      )}
                    </div>
                    <p className="text-gray-600 truncate text-sm sm:text-base">
                      {chat.lastMessage || "開始對話..."}
                    </p>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};
