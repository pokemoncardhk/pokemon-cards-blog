import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, addDoc, query, where, getDocs, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';
import { Listing } from './types';
import { useAuth } from './AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, ShieldCheck, Clock, CheckCircle2, DollarSign, X } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const ListingDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [startingChat, setStartingChat] = useState(false);
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [offerAmount, setOfferAmount] = useState('');
  const { user, setShowLoginModal } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchListing = async () => {
      if (!id) return;
      try {
        const docRef = doc(db, 'listings', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setListing({ id: docSnap.id, ...docSnap.data() } as Listing);
        }
      } catch (error) {
        console.error("Error fetching listing:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchListing();
  }, [id]);

  const getOrCreateChat = async () => {
    if (!user || !listing) return null;
    
    const chatsRef = collection(db, 'chats');
    const q = query(
      chatsRef, 
      where('participantIds', 'array-contains', user.uid),
      where('listingId', '==', listing.id)
    );
    const querySnapshot = await getDocs(q);
    
    let chatId = null;
    
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      if (data.participantIds.includes(listing.sellerId)) {
        chatId = doc.id;
      }
    });

    if (chatId) {
      return chatId;
    } else {
      const newChatRef = await addDoc(chatsRef, {
        participantIds: [user.uid, listing.sellerId],
        listingId: listing.id,
        listingTitle: listing.title,
        listingImageUrl: listing.imageUrl,
        createdAt: serverTimestamp(),
      });
      return newChatRef.id;
    }
  };

  const handleContactSeller = async () => {
    if (!listing) return;
    if (!user || user.isGuest) {
      setShowLoginModal(true);
      return;
    }
    
    setStartingChat(true);
    try {
      const chatId = await getOrCreateChat();
      if (chatId) {
        navigate(`/chat/${chatId}`);
      }
    } catch (error) {
      console.error("Error starting chat:", error);
      alert("Failed to start chat. Please try again.");
    } finally {
      setStartingChat(false);
    }
  };

  const handleMakeOfferClick = () => {
    if (!user || user.isGuest) {
      setShowLoginModal(true);
      return;
    }
    setShowOfferModal(true);
  };

  const submitOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !listing || !offerAmount) return;
    
    setStartingChat(true);
    try {
      const chatId = await getOrCreateChat();
      if (chatId) {
        // Send the offer message
        const offerMessage = `Hi! I'd like to make an offer of HK$${offerAmount} for your ${listing.title}.`;
        
        await addDoc(collection(db, `chats/${chatId}/messages`), {
          chatId: chatId,
          senderId: user.uid,
          text: offerMessage,
          createdAt: serverTimestamp(),
        });

        // Navigate to chat
        navigate(`/chat/${chatId}`);
      }
    } catch (error) {
      console.error("Error sending offer:", error);
      alert("Failed to send offer. Please try again.");
    } finally {
      setStartingChat(false);
      setShowOfferModal(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen pt-16">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="pt-32 text-center min-h-screen">
        <h2 className="text-2xl font-bold text-gray-900">找不到卡片</h2>
        <button onClick={() => navigate('/')} className="mt-4 text-blue-600 hover:underline">返回首頁</button>
      </div>
    );
  }

  return (
    <>
      <div className="pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto min-h-screen">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Image Section */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-gray-100 rounded-[2rem] overflow-hidden aspect-[3/4] lg:aspect-auto lg:h-[800px] flex items-center justify-center relative shadow-inner"
          >
            <img 
              src={listing.imageUrl} 
              alt={listing.title} 
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </motion.div>

          {/* Details Section */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col py-6"
          >
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-4">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-blue-50 text-blue-700">
                  {listing.condition}
                </span>
                {listing.createdAt && (
                  <span className="text-sm text-gray-500 flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    上架於 {formatDistanceToNow(listing.createdAt.toDate(), { addSuffix: true })}
                  </span>
                )}
              </div>
              
              <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight mb-4">
                {listing.title}
              </h1>
              <p className="text-5xl font-bold text-gray-900 tracking-tighter">
                HK${listing.price.toLocaleString()}
              </p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">關於此卡片</h3>
              <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">
                {listing.description}
              </p>
            </div>

            {/* Seller Info */}
            <div className="bg-gray-50 rounded-3xl p-6 border border-gray-100 mb-8 flex items-center justify-between">
              <div className="flex items-center gap-4">
                {listing.sellerPhoto ? (
                  <img src={listing.sellerPhoto} alt={listing.sellerName} className="w-14 h-14 rounded-full border-2 border-white shadow-sm" />
                ) : (
                  <div className="w-14 h-14 bg-gray-200 rounded-full border-2 border-white shadow-sm"></div>
                )}
                <div>
                  <p className="text-sm text-gray-500 font-medium mb-1">賣家</p>
                  <p className="text-lg font-bold text-gray-900 flex items-center gap-1">
                    {listing.sellerName}
                    <CheckCircle2 className="w-4 h-4 text-blue-500" />
                  </p>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1">
                <ShieldCheck className="w-6 h-6 text-green-500" />
                <span className="text-xs font-medium text-green-600">已驗證</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-auto pt-8 border-t border-gray-100">
              {user?.uid === listing.sellerId ? (
                <div className="bg-gray-100 text-gray-500 text-center py-4 rounded-2xl font-semibold">
                  這是您上架的卡片
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    onClick={handleMakeOfferClick}
                    disabled={startingChat}
                    className="w-full bg-white text-gray-900 border-2 border-gray-900 py-4 rounded-2xl text-lg font-bold hover:bg-gray-50 transition-all active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-70"
                  >
                    <DollarSign className="w-5 h-5" />
                    出價
                  </button>
                  <button
                    onClick={handleContactSeller}
                    disabled={startingChat}
                    className="w-full bg-gray-900 text-white py-4 rounded-2xl text-lg font-bold hover:bg-gray-800 transition-all active:scale-[0.98] flex items-center justify-center gap-2 shadow-lg shadow-gray-900/20 disabled:opacity-70"
                  >
                    {startingChat ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    ) : (
                      <>
                        <MessageCircle className="w-5 h-5" />
                        聯絡賣家
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Offer Modal */}
      <AnimatePresence>
        {showOfferModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowOfferModal(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden"
            >
              <div className="p-6">
                <button 
                  onClick={() => setShowOfferModal(false)}
                  className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-2">提出出價</h2>
                <p className="text-gray-500 mb-6 text-sm">
                  向 {listing.sellerName} 針對 {listing.title} 提出出價。
                </p>
                
                <form onSubmit={submitOffer} className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-2">您的出價 (HKD)</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <span className="text-gray-500 font-medium">$</span>
                      </div>
                      <input
                        type="number"
                        min="0"
                        step="1"
                        value={offerAmount}
                        onChange={(e) => setOfferAmount(e.target.value)}
                        placeholder={listing.price.toString()}
                        className="block w-full rounded-xl border-gray-300 bg-gray-50 py-3 pl-8 pr-4 text-gray-900 focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none text-lg font-medium"
                        required
                        autoFocus
                      />
                    </div>
                  </div>
                  
                  <button 
                    type="submit"
                    disabled={!offerAmount || startingChat}
                    className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-4 px-4 rounded-xl font-bold hover:bg-blue-700 transition-colors active:scale-[0.98] disabled:opacity-50"
                  >
                    {startingChat ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    ) : (
                      '送出出價'
                    )}
                  </button>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
