import React, { useEffect, useState, useRef } from 'react';
import { collection, query, orderBy, onSnapshot, where } from 'firebase/firestore';
import { db } from './firebase';
import { Listing } from './types';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, BookOpen, ChevronRight, ChevronLeft, Clock } from 'lucide-react';
import { ARTICLES } from './articleData';

const FeaturedArticle = ({ article }: { article: any }) => {
  const Icon = article.icon;
  return (
    <Link to={`/article/${article.id}`} className="group relative bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col h-full min-w-[85vw] sm:min-w-[350px] snap-center shrink-0">
      <div className="relative h-48 overflow-hidden bg-gray-100 shrink-0">
        <div className="absolute inset-0 bg-gray-900/20 group-hover:bg-transparent transition-colors z-10" />
        <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700" />
        <div className="absolute top-4 left-4 z-20">
          <span className="px-3 py-1 bg-white/90 backdrop-blur-md text-gray-900 text-xs font-bold uppercase tracking-wider rounded-full">
            {article.category}
          </span>
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex items-center gap-3 text-xs text-gray-500 mb-3 font-medium">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {article.readTime}
          </span>
          <span>•</span>
          <span>{article.date}</span>
        </div>
        <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors line-clamp-2">{article.title}</h3>
        <p className="text-gray-500 text-sm line-clamp-2 mb-4 flex-grow">{article.excerpt}</p>
        <div className="pt-4 border-t border-gray-100 flex items-center justify-between mt-auto">
          <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${article.color} flex items-center justify-center text-white shadow-sm`}>
            <Icon className="w-4 h-4" />
          </div>
          <span className="flex items-center gap-1 text-sm font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
            閱讀 <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </span>
        </div>
      </div>
    </Link>
  );
};

export const Home: React.FC = () => {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);

  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setShowLeftArrow(scrollLeft > 0);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    handleScroll();
    window.addEventListener('resize', handleScroll);
    return () => window.removeEventListener('resize', handleScroll);
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const container = scrollRef.current;
      // 取得單個卡片的寬度加上 gap (24px)
      const cardWidth = container.firstElementChild?.clientWidth || 350;
      const gap = 24; 
      const itemWidth = cardWidth + gap;
      
      const scrollAmount = direction === 'left' ? -itemWidth : itemWidth;
      container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const q = query(
      collection(db, 'listings'),
      where('status', '==', 'active'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedListings = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Listing[];
      setListings(fetchedListings);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching listings:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const filteredListings = listings.filter(listing => 
    listing.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    listing.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-gray-900 mb-2">
            探索卡片
          </h1>
          <p className="text-lg text-gray-500 font-medium">
            買賣稀有寶可夢卡牌。
          </p>
        </div>

        <div className="relative w-full md:w-96">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="搜尋噴火龍、皮卡丘..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-11 pr-4 py-3 bg-gray-100/50 border-0 rounded-2xl text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all shadow-sm"
          />
        </div>
      </div>

      {/* Featured Articles Section */}
      <div className="mb-16">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-blue-600" />
            收藏家指南
          </h2>
          <Link to="/articles" className="text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1 transition-colors">
            查看全部 <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        
        <div className="relative group/carousel">
          {showLeftArrow && (
            <button 
              onClick={(e) => { e.preventDefault(); scroll('left'); }}
              className="absolute left-2 sm:-left-6 top-1/2 -translate-y-1/2 z-30 bg-white shadow-xl border border-gray-100 text-gray-800 w-10 h-10 sm:w-12 sm:h-12 rounded-full hover:bg-gray-50 hover:scale-110 transition-all flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Previous articles"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}
          
          <div 
            ref={scrollRef}
            onScroll={handleScroll}
            className="flex overflow-x-auto gap-6 pb-6 -mx-4 px-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8 snap-x snap-mandatory no-scrollbar scroll-smooth"
          >
            {ARTICLES.map(article => (
              <FeaturedArticle key={article.id} article={article} />
            ))}
          </div>

          {showRightArrow && (
            <button 
              onClick={(e) => { e.preventDefault(); scroll('right'); }}
              className="absolute right-2 sm:-right-6 top-1/2 -translate-y-1/2 z-30 bg-white shadow-xl border border-gray-100 text-gray-800 w-10 h-10 sm:w-12 sm:h-12 rounded-full hover:bg-gray-50 hover:scale-110 transition-all flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Next articles"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          )}
        </div>
      </div>

      <h2 className="text-2xl font-bold text-gray-900 mb-6">最新上架</h2>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
        </div>
      ) : filteredListings.length === 0 ? (
        <div className="text-center py-24 bg-gray-50 rounded-3xl border border-gray-100">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">找不到卡片</h3>
          <p className="text-gray-500">請嘗試調整搜尋條件或稍後再試。</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredListings.map((listing, index) => (
            <motion.div
              key={listing.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Link to={`/listing/${listing.id}`} className="group block h-full">
                <div className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-xl hover:border-gray-200 transition-all duration-300 h-full flex flex-col">
                  <div className="aspect-[3/4] w-full overflow-hidden bg-gray-100 relative">
                    <img
                      src={listing.imageUrl}
                      alt={listing.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold text-gray-900 shadow-sm">
                      {listing.condition}
                    </div>
                  </div>
                  <div className="p-5 flex flex-col flex-grow">
                    <h3 className="text-lg font-semibold text-gray-900 line-clamp-1 mb-1 group-hover:text-blue-600 transition-colors">
                      {listing.title}
                    </h3>
                    <p className="text-2xl font-bold text-gray-900 mb-4 tracking-tight">
                      ${listing.price.toLocaleString()}
                    </p>
                    <div className="mt-auto flex items-center gap-2 pt-4 border-t border-gray-100">
                      {listing.sellerPhoto ? (
                        <img src={listing.sellerPhoto} alt={listing.sellerName} className="w-6 h-6 rounded-full" />
                      ) : (
                        <div className="w-6 h-6 bg-gray-200 rounded-full"></div>
                      )}
                      <span className="text-sm text-gray-500 font-medium truncate">{listing.sellerName}</span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};
