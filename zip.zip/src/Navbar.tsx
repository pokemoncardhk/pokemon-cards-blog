import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { PlusCircle, MessageCircle, LogOut, User as UserIcon, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const Navbar: React.FC = () => {
  const { user, signInWithGoogle, signInWithApple, logOut, showLoginModal, setShowLoginModal } = useAuth();
  const navigate = useNavigate();

  const handleGoogleSignIn = async () => {
    await signInWithGoogle();
  };

  const handleAppleSignIn = async () => {
    await signInWithApple();
  };

  return (
    <>
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-40 bg-white/70 backdrop-blur-xl border-b border-gray-200/50"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-sm">
                <div className="w-3 h-3 bg-white rounded-full border-2 border-red-600"></div>
              </div>
              <span className="font-semibold text-xl tracking-tight text-gray-900">PokéMarket</span>
            </Link>

            <div className="flex items-center gap-4">
              <Link to="/create" className="text-gray-600 hover:text-gray-900 transition-colors flex items-center gap-1 text-sm font-medium">
                <PlusCircle className="w-5 h-5" />
                <span className="hidden sm:inline">Sell</span>
              </Link>
              <Link to="/chats" className="text-gray-600 hover:text-gray-900 transition-colors flex items-center gap-1 text-sm font-medium">
                <MessageCircle className="w-5 h-5" />
                <span className="hidden sm:inline">Chats</span>
              </Link>
              <div className="h-4 w-px bg-gray-300 mx-2"></div>
              
              {user && !user.isGuest ? (
                <>
                  <button 
                    onClick={logOut}
                    className="text-gray-600 hover:text-gray-900 transition-colors flex items-center gap-1 text-sm font-medium"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="hidden sm:inline">Log Out</span>
                  </button>
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="Profile" className="w-8 h-8 rounded-full border border-gray-200" />
                  ) : (
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center border border-gray-200">
                      <UserIcon className="w-4 h-4 text-gray-500" />
                    </div>
                  )}
                </>
              ) : (
                <button
                  onClick={() => setShowLoginModal(true)}
                  className="bg-gray-900 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-gray-800 transition-all active:scale-95"
                >
                  Sign In
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.nav>

      <AnimatePresence>
        {showLoginModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLoginModal(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden"
            >
              <div className="p-6 text-center">
                <button 
                  onClick={() => setShowLoginModal(false)}
                  className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-sm mx-auto mb-4">
                  <div className="w-4 h-4 bg-white rounded-full border-2 border-red-600"></div>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome Back</h2>
                <p className="text-gray-500 mb-8 text-sm">Sign in to buy, sell, and chat about your favorite Pokémon cards.</p>
                
                <div className="space-y-3">
                  <button 
                    onClick={handleAppleSignIn}
                    className="w-full flex items-center justify-center gap-3 bg-black text-white py-3 px-4 rounded-xl font-medium hover:bg-gray-900 transition-colors active:scale-[0.98]"
                  >
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2C6.477 2 2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.879V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.989C18.343 21.129 22 16.99 22 12c0-5.523-4.477-10-10-10z" opacity="0" />
                      <path d="M17.05 20.28c-.98.19-2.05.08-3.08-.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C4.79 17.3 3.46 12.05 5.6 9.16c1.06-1.44 2.61-2.36 4.32-2.4 1.46-.04 2.84.96 3.75.96.91 0 2.58-1.2 4.35-1.02 1.48.05 2.83.6 3.73 1.9-3.15 1.94-2.61 6.51.5 7.74-.75 1.94-1.66 3.96-3.2 6.14zm-3.87-14.7c-.82-.98-2.2-1.64-3.46-1.6-.22 1.4.45 2.82 1.3 3.78.8.92 2.26 1.63 3.42 1.55.18-1.44-.45-2.76-1.26-3.73z" />
                    </svg>
                    Continue with Apple
                  </button>
                  
                  <button 
                    onClick={handleGoogleSignIn}
                    className="w-full flex items-center justify-center gap-3 bg-white text-gray-700 border border-gray-300 py-3 px-4 rounded-xl font-medium hover:bg-gray-50 transition-colors active:scale-[0.98]"
                  >
                    <svg className="w-5 h-5" viewBox="0 0 24 24">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                    </svg>
                    Continue with Google
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
