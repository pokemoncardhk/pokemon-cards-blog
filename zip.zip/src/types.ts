export interface User {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  createdAt: any;
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: number;
  condition: 'Mint' | 'Near Mint' | 'Excellent' | 'Good' | 'Lightly Played' | 'Played' | 'Poor';
  imageUrl: string;
  sellerId: string;
  sellerName: string;
  sellerPhoto: string;
  status: 'active' | 'sold';
  createdAt: any;
}

export interface Chat {
  id: string;
  participantIds: string[];
  listingId: string;
  listingTitle: string;
  listingImageUrl: string;
  lastMessage?: string;
  lastMessageAt?: any;
  createdAt: any;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  text: string;
  createdAt: any;
}
