import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';
import { useAuth } from './AuthContext';
import imageCompression from 'browser-image-compression';
import { UploadCloud, Loader2, Image as ImageIcon } from 'lucide-react';
import { motion } from 'framer-motion';

export const CreateListing: React.FC = () => {
  const { user, setShowLoginModal } = useAuth();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [condition, setCondition] = useState('Mint');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const applyTemplate = async (type: 'pikachu' | 'charizard') => {
    if (type === 'pikachu') {
      setTitle('2023 Pikachu with Grey Felt Hat - Pokemon x Van Gogh (PSA 10)');
      setDescription('2023 Pokemon SVP EN Pikachu/Grey Felt Hat Pokemon x Van Gogh.\nCard Number: #085\nGraded PSA 10 Gem Mint.\nCert: 124578281\n\nPerfect condition, highly sought after promo card.');
      setPrice('23000');
      setCondition('Mint');
      
      try {
        const response = await fetch('https://images.psacard.com/s3/ig-pop/124578281-front.jpg');
        const blob = await response.blob();
        const file = new File([blob], 'pikachu.jpg', { type: 'image/jpeg' });
        setImageFile(file);
        
        const reader = new FileReader();
        reader.onloadend = () => {
          setImagePreview(reader.result as string);
        };
        reader.readAsDataURL(file);
      } catch (e) {
        console.error("Failed to load template image", e);
      }
    } else {
      setTitle('1996 PM Japanese Basic Charizard Holo (PSA 10)');
      setDescription('1996 PM Japanese Basic Charizard - Holo.\nCard Number: #6\nGraded PSA 10 Gem Mint.\nCert: 52064167\n\nLegendary vintage Charizard in perfect PSA 10 condition. A holy grail for collectors.');
      setPrice('150000');
      setCondition('Mint');
      
      try {
        const response = await fetch('https://images.psacard.com/s3/ig-pop/52064167-front.jpg');
        const blob = await response.blob();
        const file = new File([blob], 'charizard.jpg', { type: 'image/jpeg' });
        setImageFile(file);
        
        const reader = new FileReader();
        reader.onloadend = () => {
          setImagePreview(reader.result as string);
        };
        reader.readAsDataURL(file);
      } catch (e) {
        console.error("Failed to load template image", e);
      }
    }
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setError('You must be logged in to create a listing.');
      return;
    }
    if (!imageFile) {
      setError('Please upload an image of the card.');
      return;
    }
    if (!title || !description || !price) {
      setError('Please fill in all fields.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Compress image to fit within Firestore 1MB limit (aim for < 500KB)
      const options = {
        maxSizeMB: 0.5,
        maxWidthOrHeight: 1024,
        useWebWorker: true,
      };
      
      const compressedFile = await imageCompression(imageFile, options);
      
      // Convert to base64
      const base64Image = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(compressedFile);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
      });

      // Save to Firestore
      const docRef = await addDoc(collection(db, 'listings'), {
        title,
        description,
        price: parseFloat(price),
        condition,
        imageUrl: base64Image,
        sellerId: user.uid,
        sellerName: user.displayName || 'Anonymous',
        sellerPhoto: user.photoURL || '',
        status: 'active',
        createdAt: serverTimestamp(),
      });

      navigate(`/listing/${docRef.id}`);
    } catch (err: any) {
      console.error('Error creating listing:', err);
      setError(err.message || 'Failed to create listing. The image might still be too large.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto min-h-screen"
    >
      <div className="bg-white rounded-[2rem] shadow-xl border border-gray-100 overflow-hidden">
        <div className="p-8 md:p-12">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 mb-2">Sell a Card</h1>
          <p className="text-gray-500 mb-8">List your Pokémon card for auction or sale.</p>

          <div className="mb-8 p-4 bg-blue-50 rounded-2xl border border-blue-100">
            <p className="text-sm font-semibold text-blue-900 mb-3">⚡ Quick Fill Templates</p>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => applyTemplate('pikachu')}
                className="px-4 py-2 bg-white text-blue-700 text-sm font-medium rounded-xl border border-blue-200 hover:bg-blue-100 transition-colors shadow-sm"
              >
                Pikachu Van Gogh (PSA 10)
              </button>
              <button
                type="button"
                onClick={() => applyTemplate('charizard')}
                className="px-4 py-2 bg-white text-blue-700 text-sm font-medium rounded-xl border border-blue-200 hover:bg-blue-100 transition-colors shadow-sm"
              >
                1996 Charizard Holo (PSA 10)
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-6 text-sm font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Image Upload */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">Card Photo</label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-2xl hover:border-blue-500 hover:bg-blue-50 transition-colors relative overflow-hidden group">
                {imagePreview ? (
                  <div className="absolute inset-0 w-full h-full">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-contain bg-gray-100" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <p className="text-white font-medium flex items-center gap-2">
                        <UploadCloud className="w-5 h-5" /> Change Photo
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1 text-center">
                    <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600 justify-center">
                      <span className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                        Upload a file
                      </span>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG up to 5MB</p>
                  </div>
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-900 mb-2">Card Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Base Set Charizard Holo"
                  className="block w-full rounded-xl border-gray-300 bg-gray-50 py-3 px-4 text-gray-900 focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Price (HKD)</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <span className="text-gray-500 font-medium">$</span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="0.00"
                    className="block w-full rounded-xl border-gray-300 bg-gray-50 py-3 pl-8 pr-4 text-gray-900 focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Condition</label>
                <select
                  value={condition}
                  onChange={(e) => setCondition(e.target.value)}
                  className="block w-full rounded-xl border-gray-300 bg-gray-50 py-3 px-4 text-gray-900 focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none appearance-none"
                >
                  <option>Mint</option>
                  <option>Near Mint</option>
                  <option>Excellent</option>
                  <option>Good</option>
                  <option>Lightly Played</option>
                  <option>Played</option>
                  <option>Poor</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-900 mb-2">Description</label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe the card's history, specific flaws, or any other details..."
                  className="block w-full rounded-xl border-gray-300 bg-gray-50 py-3 px-4 text-gray-900 focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none resize-none"
                  required
                />
              </div>
            </div>

            <div className="pt-4">
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center items-center py-4 px-4 border border-transparent rounded-xl shadow-sm text-lg font-bold text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98]"
              >
                {loading ? (
                  <>
                    <Loader2 className="animate-spin -ml-1 mr-2 h-5 w-5" />
                    Publishing...
                  </>
                ) : (
                  'List Card for Sale'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </motion.div>
  );
};
