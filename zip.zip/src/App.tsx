import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './AuthContext';
import { Navbar } from './Navbar';
import { Home } from './Home';
import { CreateListing } from './CreateListing';
import { ListingDetail } from './ListingDetail';
import { ChatList } from './ChatList';
import { ChatDetail } from './ChatDetail';

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50 font-sans text-gray-900 selection:bg-blue-200 selection:text-blue-900">
          <Navbar />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/create" element={<CreateListing />} />
              <Route path="/listing/:id" element={<ListingDetail />} />
              <Route path="/chats" element={<ChatList />} />
              <Route path="/chat/:id" element={<ChatDetail />} />
            </Routes>
          </main>
        </div>
      </Router>
    </AuthProvider>
  );
}
