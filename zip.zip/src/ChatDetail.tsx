import React, { useEffect, useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from './firebase';
import { Chat, Message } from './types';
import { useAuth } from './AuthContext';
import { motion } from 'framer-motion';
import { Send, ArrowLeft, Image as ImageIcon, MessageSquare } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export const ChatDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user, setShowLoginModal } = useAuth();
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (!id || !user) return;

    const fetchChat = async () => {
      const chatRef = doc(db, 'chats', id);
      const chatSnap = await getDoc(chatRef);
      if (chatSnap.exists()) {
        setChat({ id: chatSnap.id, ...chatSnap.data() } as Chat);
      }
    };
    fetchChat();

    const q = query(
      collection(db, `chats/${id}/messages`),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedMessages = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Message[];
      setMessages(fetchedMessages);
      setLoading(false);
      setTimeout(scrollToBottom, 100);
    }, (error) => {
      console.error("Error fetching messages:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [id, user]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || !id || !chat) return;

    const messageText = newMessage.trim();
    setNewMessage('');

    try {
      // Add message
      await addDoc(collection(db, `chats/${id}/messages`), {
        chatId: id,
        senderId: user.uid,
        text: messageText,
        createdAt: serverTimestamp(),
      });

      // Update chat last message
      await updateDoc(doc(db, 'chats', id), {
        lastMessage: messageText,
        lastMessageAt: serverTimestamp(),
      });
    } catch (error) {
      console.error("Error sending message:", error);
      alert("Failed to send message.");
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen pt-16">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!chat) {
    return (
      <div className="pt-32 text-center min-h-screen">
        <h2 className="text-2xl font-bold text-gray-900">Chat not found</h2>
      </div>
    );
  }

  return (
    <div className="pt-16 flex flex-col h-[100dvh] bg-gray-50 max-w-4xl mx-auto">
      {/* Chat Header */}
      <div className="bg-white/80 backdrop-blur-xl border-b border-gray-200 px-4 py-3 flex items-center gap-4 sticky top-16 z-30 shadow-sm">
        <Link to="/chats" className="p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-600">
          <ArrowLeft className="w-6 h-6" />
        </Link>
        <Link to={`/listing/${chat.listingId}`} className="flex items-center gap-3 flex-grow min-w-0">
          <img 
            src={chat.listingImageUrl} 
            alt={chat.listingTitle} 
            className="w-12 h-12 rounded-lg object-cover border border-gray-200 flex-shrink-0"
            referrerPolicy="no-referrer"
          />
          <div className="truncate">
            <h2 className="text-lg font-bold text-gray-900 truncate">{chat.listingTitle}</h2>
            <p className="text-sm text-gray-500 font-medium">View listing details</p>
          </div>
        </Link>
      </div>

      {/* Messages Area */}
      <div className="flex-grow overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-1">Start the conversation</h3>
            <p className="text-gray-500 text-sm">Say hello and ask about the card!</p>
          </div>
        ) : (
          messages.map((msg, index) => {
            const isMe = msg.senderId === user.uid;
            const showTime = index === 0 || (msg.createdAt?.toMillis() - messages[index-1].createdAt?.toMillis() > 300000); // 5 mins
            
            return (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                {showTime && msg.createdAt && (
                  <span className="text-xs text-gray-400 font-medium mb-2 px-2">
                    {formatDistanceToNow(msg.createdAt.toDate(), { addSuffix: true })}
                  </span>
                )}
                <div 
                  className={`max-w-[75%] sm:max-w-[60%] rounded-2xl px-4 py-3 text-[15px] leading-relaxed shadow-sm ${
                    isMe 
                      ? 'bg-blue-600 text-white rounded-br-sm' 
                      : 'bg-white text-gray-900 border border-gray-100 rounded-bl-sm'
                  }`}
                >
                  {msg.text}
                </div>
              </motion.div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-gray-200 p-4 pb-safe">
        <form onSubmit={handleSendMessage} className="flex items-end gap-3 max-w-4xl mx-auto">
          <div className="flex-grow relative">
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="w-full bg-gray-100 border-transparent rounded-2xl py-3 pl-4 pr-12 text-gray-900 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500 transition-all resize-none outline-none overflow-hidden"
              rows={1}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage(e);
                }
              }}
              style={{ minHeight: '48px', maxHeight: '120px' }}
            />
          </div>
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="bg-blue-600 text-white p-3 rounded-full hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0 shadow-sm active:scale-95"
          >
            <Send className="w-6 h-6" />
          </button>
        </form>
      </div>
    </div>
  );
};
