import React, { createContext, useContext, useEffect, useState } from 'react';
import { User as FirebaseUser, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, googleProvider, appleProvider } from './firebase';

// Extend the user type to support our guest user
export interface AppUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  isGuest?: boolean;
}

interface AuthContextType {
  user: AppUser | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithApple: () => Promise<void>;
  logOut: () => Promise<void>;
  showLoginModal: boolean;
  setShowLoginModal: (show: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const getGuestUser = (): AppUser => {
  let guestId = localStorage.getItem('guest_uid');
  if (!guestId) {
    guestId = 'guest_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('guest_uid', guestId);
  }
  return {
    uid: guestId,
    email: null,
    displayName: 'Guest User',
    photoURL: `https://api.dicebear.com/7.x/avataaars/svg?seed=${guestId}`,
    isGuest: true
  };
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [showLoginModal, setShowLoginModal] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        const appUser: AppUser = {
          uid: currentUser.uid,
          email: currentUser.email,
          displayName: currentUser.displayName || 'Anonymous User',
          photoURL: currentUser.photoURL,
        };
        setUser(appUser);
        
        // Ensure user exists in Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: currentUser.uid,
            email: currentUser.email || '',
            displayName: currentUser.displayName || 'Anonymous User',
            photoURL: currentUser.photoURL || '',
            createdAt: serverTimestamp(),
          });
        }
      } else {
        // If not logged in via Firebase, use a persistent guest user
        const guestUser = getGuestUser();
        setUser(guestUser);
        
        // Ensure guest user exists in Firestore
        const userRef = doc(db, 'users', guestUser.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: guestUser.uid,
            email: '',
            displayName: guestUser.displayName,
            photoURL: guestUser.photoURL,
            createdAt: serverTimestamp(),
            isGuest: true
          });
        }
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      setShowLoginModal(false);
    } catch (error) {
      console.error('Error signing in with Google', error);
    }
  };

  const signInWithApple = async () => {
    try {
      await signInWithPopup(auth, appleProvider);
      setShowLoginModal(false);
    } catch (error) {
      console.error('Error signing in with Apple', error);
    }
  };

  const logOut = async () => {
    try {
      await signOut(auth);
      // After sign out, the onAuthStateChanged will set the guest user
    } catch (error) {
      console.error('Error signing out', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signInWithGoogle, signInWithApple, logOut, showLoginModal, setShowLoginModal }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
